
def test_function():
    myvar = 12
    print(myvar)

    array = [1, 2, 3, 4, 5]

    # iterate through each array element
    for item in array:
        # this is a comment, ignore this line and the next line
        # print(item)

        # sum the total of myvar plus the current array item
        myvar = myvar + item
        print('New total: ', myvar)


def myfunction():
    print(12)
