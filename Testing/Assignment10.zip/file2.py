import test

test.myfunction()